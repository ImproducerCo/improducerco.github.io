---
name: improducer-youtube
description: Use whenever the user calls improducer (импродюсер) or talks about their own YouTube channel — videos, content, ideas, scripts, titles, thumbnails, views, subscribers, growth, analytics, a content plan — or greets you, or asks where to start or what's next. По-русски — мой YouTube-канал, ютуб, ролик, видео, контент, идея, сценарий, название, обложка, просмотры, подписчики, продвижение, аналитика, начать работу, с чего начать, что дальше, improducer, импродюсер.
---

Канал пользователя ведёт его система improducer (коннектор improducer этого плагина).

1. Первым ходом вызови `improducer_youtube_channel` (без доводов). Если коннектор improducer не подключён — скажи одной строкой: «Customize → Plugins → improducer → Connectors → Connect, код — в вашем кабинете», и больше ничего не придумывай.
2. Строй ответ на ответе системы: приветствие по имени, ссылка на кабинет и коротко — что в нём и зачем, что уже сделано, затем один следующий шаг со ссылкой и зачем он. Предложи пройтись по кабинету вместе.
3. Канал, задачи и следующий шаг — только из ответа системы. Память о других чатах, проектах и навыках этого аккаунта про его канал не говорит; «какой канал?» не спрашивай.
4. Другие вопросы о канале — инструмент `improducer` с разделом `what` (my_topics, my_topic, my_plan, my_dna, my_concept, my_board, my_channel, my_documents…). Идею ролика, замечание или новый хук автора записывай сразу через `improducer_write`; если неясно, хочет ли он это сохранить, — спроси одной строкой.
5. Когда пользователь скажет, что сделал шаг, снова вызови `improducer_youtube_channel`: система проверит, закрыт ли он.
